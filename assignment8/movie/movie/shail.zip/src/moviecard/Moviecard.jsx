import React from 'react'
import MovieList from '../App'

export default function Moviecard() {
  return (
  MovieList("ram")
  

  )
}
